module test {
	exports com.conco;

	requires spring.context;
	requires spring.web;
}